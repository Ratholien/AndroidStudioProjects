package com.example.sifo.apprepartos;

import android.app.Activity;


import android.app.ProgressDialog;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.net.Uri;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;

import android.util.Log;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import android.widget.ListView;
import android.widget.Toast;

import com.melnykov.fab.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;



/**
 * Created by Sifo on 17/02/2016.
 */
public class ListRepartos extends AppCompatActivity {


    private ListView lista, loclist;
    private ArrayList<String> locs = new ArrayList<String>();
    protected static ArrayList<Reparto> arrayList = new ArrayList<Reparto>();
    private SQLiteDatabase sdb;
    private static Adaptador a;

    private DevuelveJSON devuelveJSON;
    private ProgressDialog pDialog;

    private boolean todos;
    private HashMap<String, String> parametrosPost = new HashMap<>();
    private Drawable iconReparto;
    private String user;
    private Drawable enviado;
    private int pos;
    private Reparto reparto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.repartos);

        devuelveJSON = new DevuelveJSON();

        user = MainActivity.user.getText().toString();
        iconReparto = getResources().getDrawable(R.drawable.ic_truck_delivery_grey600_48dp);
        enviado = getResources().getDrawable(R.drawable.enviado);

        //list view principal y list view del navigation view
        lista = (ListView) findViewById(R.id.lista);
        loclist = (ListView) findViewById(R.id.loclist);


        //añadir FAB a ListView
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.attachToListView(lista);


        //limpiar el array cada vez que se crea(evita duplicados)
        if (arrayList.size() > 0) {
            arrayList.clear();
        }

        //coger los datos de la bd
        sdb = MainActivity.getBD().getReadableDatabase();
        Cursor res = sdb.rawQuery("SELECT clocalidad,cdireccion,nnumreparto from repartos " +
                "WHERE ccodrepartidor = '" + MainActivity.user.getText().toString() + "' and BACTUALIZADO ='n' order by clocalidad,cdireccion", null);

        if (res.getCount() == 0) {
            Toast.makeText(this, R.string.norepartos, Toast.LENGTH_LONG).show();
            Log.e("CURSOR", "VACIO");
        } else {
            while (res.moveToNext()) {
                Log.e("CURSOR", "LLENO_>" + res.getCount());
                arrayList.add(new Reparto(res.getString(0), res.getString(1), res.getInt(2), iconReparto));
            }
        }

        a = new Adaptador(this, arrayList);
        lista.setAdapter(a);
        res.close();
        //Lleno el navigation View para ordenar
        llenarNV();
        //Se ordenan segun lo que se pulse
        filtro(this);
        //Muestra un dialog con las opciones del reparto
        opsLV(this);
    }

    //lleno el listview del navigation view con las localidades
    public void llenarNV() {
        //limpio el Navigation View y le añado una fila en blanco(para mejor presentacion)
        locs.clear();
        locs.add("");

        Cursor res = sdb.rawQuery("select distinct clocalidad from repartos " +
                "where ccodrepartidor = '" + MainActivity.user.getText().toString() + "' and BACTUALIZADO ='n'", null);
        while (res.moveToNext()) {
            locs.add(res.getString(0));
        }
        locs.add("Mostrar todos");
        ArrayAdapter adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, locs);
        loclist.setAdapter(adaptador);
        res.close();
    }

    //Hace el filtro al pulsar en las localidades anteriormente introducidas
    public void filtro(final Activity activity) {
        loclist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cursor res;
                String localizacion = loclist.getItemAtPosition(position).toString();
                Log.e("localidad:", localizacion);

                if (localizacion.equals("Mostrar todos")) {
                    res = sdb.rawQuery("SELECT distinct clocalidad,cdireccion,nnumreparto from repartos " +
                            "WHERE ccodrepartidor = '" + MainActivity.user.getText().toString() + "' and bactualizado = 'n' order by clocalidad,cdireccion", null);
                } else {
                    res = sdb.rawQuery("SELECT distinct clocalidad,cdireccion,nnumreparto from repartos " +
                            "WHERE ccodrepartidor = '" + MainActivity.user.getText().toString() + "' and bactualizado = 'n' and clocalidad = '" + localizacion + "'", null);
                }


                arrayList.clear();
                while (res.moveToNext()) {
                    Log.e("CURSOR", "LLENO_>" + res.getCount());
                    arrayList.add(new Reparto(res.getString(0), res.getString(1), res.getInt(2), iconReparto));
                }
                a = new Adaptador(activity, arrayList);
                lista.setAdapter(a);
                res.close();
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);

            }
        });
    }

    //Lo mejor seria crearse una clase aparte, pero por falta de tiempo se ha adaptado así
    class Consulta extends AsyncTask<String, String, Boolean> {


        String IP_Server = MainActivity.getIP_Server();
        String url_consulta = "http://" + IP_Server + "/Android/consulta2.php";


        //Antes de ejecutarse crea un icono de CARGANDO
        @Override
        protected void onPreExecute() {
            pDialog = new ProgressDialog(ListRepartos.this);
            pDialog.setMessage("Actualizando...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        @Override
        protected Boolean doInBackground(String... params) {

            JSONArray jsonArray;
            if (todos) {

                for (int i = 0; i < arrayList.size(); i++) {
                    parametrosPost.put("update", "UPDATE repartos SET bactualizado = 's'" +
                            "WHERE nnumreparto = '" + arrayList.get(i).getNum() + "' and bactualizado = 'n' and bentregado = 's'");

                    try {
                        jsonArray = devuelveJSON.sendRequest(url_consulta, parametrosPost);
                        //Si esta a null -> Malo. Si tiene "conexion" o "update : no" -> Malo. Si tiene "update : si " -> Bueno.
                        //Si malo-> no se ha hecho el update. Si bueno-> Si se ha hecho el update
                        if (jsonArray != null) {
                            if (jsonArray.getJSONObject(0).has("Conexion") || jsonArray.getJSONObject(0).getString("Update").equals("null")) {

                                return false;
                            }
                        } else {

                            return false;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Log.e("Petada al guardar", "LOL");
                    }
                    parametrosPost.clear();
                    return true;
                }
            } else {
                try {
                    jsonArray = devuelveJSON.sendRequest(url_consulta, parametrosPost);
                    //Si esta a null -> Malo. Si tiene "conexion" o "update : no" -> Malo. Si tiene "update : si " -> Bueno.
                    //Si malo-> no se ha hecho el update. Si bueno-> Si se ha hecho el update
                    if (jsonArray != null) {
                        if (jsonArray.getJSONObject(0).has("Conexion") || jsonArray.getJSONObject(0).getString("Update").equals("no")) {

                            return false;
                        }
                    } else {

                        return false;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.e("Petada al guardar", "LOL");
                }
                parametrosPost.clear();
                return true;
            }
            return true;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            if (!todos) {
                //si es true, es que se ha modificado en el servidor.
                if (aBoolean) {
                    //bd local
                    ContentValues values = new ContentValues();
                    values.put("bentregado", "s");
                    values.put("bactualizado", "s");
                    sdb.update("repartos", values, "nnumreparto =" + reparto.getNum(), null);

                    //cambia el icono del list view
                    arrayList.get(pos).setDrawable(enviado);
                    a = new Adaptador(ListRepartos.this, arrayList);
                    lista.setAdapter(a);
                    Toast.makeText(getApplicationContext(), R.string.repartoActualizado, Toast.LENGTH_SHORT).show();
                    //si es false solo lo pone a entregado pero no actualiza en el servidor
                } else {
                    ContentValues values = new ContentValues();
                    values.put("bentregado", "s");
                    sdb.update("repartos", values, "nnumreparto =" + reparto.getNum(), null);
                    Toast.makeText(getApplicationContext(), R.string.noConexion, Toast.LENGTH_SHORT).show();

                }
            } else {
                if (aBoolean) {
                    ContentValues values = new ContentValues();
                    values.put("bentregado", "s");
                    values.put("bactualizado", "s");
                    sdb.update("repartos", values, "bentregado ='s' and bactualizado ='n'", null);
                    Cursor res = sdb.rawQuery("SELECT distinct clocalidad,cdireccion,nnumreparto from repartos " +
                            "WHERE ccodrepartidor = '" + MainActivity.user.getText().toString() + "' and bactualizado = 'n' order by clocalidad,cdireccion", null);

                    if (res.getCount() > 0) {
                        arrayList.clear();
                        while (res.moveToNext()) {
                            arrayList.add(new Reparto(res.getString(0), res.getString(1), res.getInt(2), iconReparto));
                        }
                        res.close();
                    }
                    a = new Adaptador(ListRepartos.this, arrayList);
                    lista.setAdapter(a);


                    Toast.makeText(getApplicationContext(), R.string.repartosActualizados, Toast.LENGTH_SHORT).show();
                } else {

                    Toast.makeText(getApplicationContext(), R.string.noConexion, Toast.LENGTH_SHORT).show();
                }


            }
            if (pDialog != null && pDialog.isShowing()) {
                pDialog.dismiss();
            }

        }
    }


    public void guardar(View v) {
        todos = true;

        Consulta c = new Consulta();
        c.execute();

    }


    public void opsLV(final Activity activity) {
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                //Log.e("has hecho click",position+"");
                //Creamos un objeto reparto que va a tener los datos del reparto que pulsemos7
                pos = position;
                reparto = arrayList.get(position);

                final int numreparto = reparto.getNum();

                final String[] items = {"Localizacion", "Ver Detalles", "Confirmar Entrega"};

                AlertDialog.Builder builder = new AlertDialog.Builder(activity);

                builder.setTitle(R.string.opcionesreparto)
                        //creamos un dialog con las 3 opciones al pulsar sobre un item
                        .setItems(items, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int item) {
                                //si pulsamos en localizacion, nos coje la direccion y la localidad de la bd local y nos hace un Intent.Action_view de esa direccion
                                if (items[item].equals("Localizacion")) {
                                    Cursor dir = sdb.rawQuery("select cdireccion,clocalidad from repartos where ccodrepartidor = '" + MainActivity.user.getText().toString() + "' and nnumreparto = " + numreparto, null);
                                    dir.moveToNext();
                                    //abrir la geolocalizacion
                                    Intent i = new Intent(Intent.ACTION_VIEW);
                                    //se le manda direcion , localidad
                                    i.setData(Uri.parse("geo:0,0?q=" + dir.getString(0) + "," + dir.getString(1)));
                                    dir.close();
                                    startActivity(i);
                                }


                                if (items[item].equals("Ver Detalles")) {
                                    //pasamos el numero de reparto para que trabaje con el en la otra clase
                                    Intent detalles = new Intent(getApplication(), Detalles.class);
                                    detalles.putExtra("codReparto", reparto.getNum());
                                    startActivity(detalles);
                                }

                                //actualiza en el servidor y si hay conexion actualiza en la bd local, si no pone bentregado 's' bactualizado 'n' (en local)
                                if (items[item].equals("Confirmar Entrega")) {

                                    //bd servidor
                                    parametrosPost.put("update", "update repartos set bentregado='s', bactualizado ='s' where nnumreparto = " + numreparto);
                                    todos = false;
                                    Consulta c = new Consulta();
                                    c.execute();


                                }
                            }
                        });

                builder.create();
                builder.show();

            }
        });
    }


}
