package com.example.sifo.apprepartos;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;


public class MainActivity extends AppCompatActivity {
    private static BDrepartos bd;
    private static SQLiteDatabase sdb;

    private static String IP_Server = "";
    private static String url_consulta = "";

    private JSONArray jSONArray;
    private JSONObject jsonObject = new JSONObject();
    private DevuelveJSON devuelveJSON;


    public static EditText user;
    public static EditText pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user = (EditText) findViewById(R.id.editText);
        pass = (EditText) findViewById(R.id.editText2);

        bd = new BDrepartos(this);
        sdb = bd.getWritableDatabase();

        devuelveJSON = new DevuelveJSON();

        SharedPreferences prefs = getSharedPreferences("com.example.sifo.apprepartos_preferences", MODE_PRIVATE);

        IP_Server = prefs.getString("ip", "192.168.0.163");
        user.setText(prefs.getString("codigo", ""));
        url_consulta = "http://" + IP_Server + "/Android/ConsultaSQL.php";


    }


    public static BDrepartos getBD() {
        return bd;
    }



    public static String getIP_Server() {
        return IP_Server;
    }

    public void goPrefs(View view) {
        Intent i = new Intent(this, Preferencias.class);
        startActivityForResult(i, 0);

    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences prefs = getSharedPreferences("com.example.sifo.apprepartos_preferences", MODE_PRIVATE);
        IP_Server = prefs.getString("ip", "192.168.0.0");
        user.setText(prefs.getString("codigo", ""));
        url_consulta = "http://" + IP_Server + "/Android/ConsultaSQL.php";
    }

    class ListaUsuario extends AsyncTask<String, String, JSONArray> {
        private ProgressDialog pDialog;

        //Antes de ejecutarse crea un icono de CARGANDO
        @Override
        protected void onPreExecute() {
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Validando...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

        }

        //En segundo plano
        protected JSONArray doInBackground(String... args) {

            if (pDialog.isShowing()) {

                try {
                    HashMap<String, String> parametrosPost = new HashMap<>();
                    parametrosPost.put("ins_sql", "SELECT * FROM localidades l,repartidores rs, repartos r, repartosdetalle rd " +
                            "where rs.ccodrepartidor = '" + args[0] + "' and rs.cpassrepartidor ='" + args[1] + "' and r.BENTREGADO = 'n' " +
                            "and rs.ccodrepartidor = r.CCODREPARTIDOR and r.clocalidad = l.clocalidad and rd.nnumreparto = r.nnumreparto ");


                    jSONArray = devuelveJSON.sendRequest(url_consulta, parametrosPost);

                    if (jSONArray != null) {
                        return jSONArray;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
            return null;
        }


        protected void onPostExecute(JSONArray json) {

            if (pDialog != null && pDialog.isShowing()) {
                pDialog.dismiss();
            }
            if (json!=null) {

                //entra si el usuario existe en la base de datos externa y hay registros

                try {

                    jsonObject = json.getJSONObject(0);
                    //si ha devuelto "Conexion" es que no se ha podido conectar con el servidor web
                    if (jsonObject.has("Conexion")) {

                        //hago la consulta en local
                        Cursor res = sdb.rawQuery("SELECT * FROM repartidores WHERE CCODREPARTIDOR = '" + user.getText().toString() + "' and CPASSREPARTIDOR = '" + pass.getText().toString() + "'", null);
                        if (res.getCount() == 0) {
                            res.close();
                            Toast.makeText(MainActivity.this, R.string.noDatos, Toast.LENGTH_LONG).show();

                        } else {
                            Toast.makeText(MainActivity.this, R.string.sinConexion, Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(getApplication(), ListRepartos.class);
                            startActivity(i);
                        }

                    } else {
                        if (jsonObject.has("array")) {
                           Toast.makeText(MainActivity.this,R.string.noDatos,Toast.LENGTH_LONG).show();
                        }else{
                            /*
                            * si tiene repartos, comparo la fecha. Si es igual es que tiene los repartos de hoy. Si no, actualiza
                            * la fecha se actualizaria mediante un trigger automatizado en la bd externa
                            */
                            Cursor fec = sdb.rawQuery("SELECT dfecultact from repartidores where ccodrepartidor = '"+user+"' and cpassrepartidor = '"+pass+"'",null);

                            if(fec.getCount()>0) {
                                fec.moveToNext();
                                String fecha = fec.getString(0);
                                fec.close();
                                if (jsonObject.getString("dfecultact").equals(fecha)) {
                                    Intent i = new Intent(getApplication(), ListRepartos.class);
                                    startActivity(i);
                                } else {
                                    //si hay conexion, inserto datos machacando lo que haya en la bd local
                                    insertarDatos(json);
                                    Intent i = new Intent(getApplication(), ListRepartos.class);
                                    startActivity(i);
                                }
                            }else{
                                //sin datos en la bd local
                                insertarDatos(json);
                                Intent i = new Intent(getApplication(), ListRepartos.class);
                                startActivity(i);
                            }

                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();

                }

            } else  {
                Toast.makeText(MainActivity.this, R.string.noDatos, Toast.LENGTH_LONG).show();


            }
        }

    }

    public void checkConexion(View view) {

        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {

            new ListaUsuario().execute(user.getText().toString(), pass.getText().toString());
        } else {
            //si no hay internet l(bd sqlite)
            Cursor res = sdb.rawQuery("SELECT * FROM repartidores where ccodrepartidor = '" + user.getText().toString() + "' and cpassrepartidor = '" + pass.getText().toString() + "'", null);
            if (res.getCount() > 0) {

                Intent i = new Intent(this, ListRepartos.class);
                startActivity(i);
            } else {
                Toast.makeText(this, R.string.noDatos, Toast.LENGTH_LONG).show();
            }
            res.close();


        }

    }

    //inserta los datos en la BD local habiendo obtenido previamente el objeto de la BD en el servidor
    public void insertarDatos(JSONArray jsonArray) {

        ContentValues valRepartidores = new ContentValues();
        ContentValues valRepartos = new ContentValues();
        ContentValues valLocs = new ContentValues();
        ContentValues valRepartosDet = new ContentValues();
        boolean primero = true;
        try {

            sdb.delete("repartosdetalle", "", null);
            sdb.delete("repartos", "", null);
            sdb.delete("localidades", "", null);
            sdb.delete("repartidores", "", null);
            for (int i = 0; i < jsonArray.length(); i++) {
                jsonObject = jsonArray.getJSONObject(i);

                if (jsonObject != null) {
                    valRepartidores.put("DFECULTACT", jsonObject.getString("DFECULTACT"));
                    valRepartidores.put("CNOMREPARTIDOR", jsonObject.getString("CNOMREPARTIDOR"));
                    valRepartidores.put("CCODREPARTIDOR", jsonObject.getString("CCODREPARTIDOR"));
                    valRepartidores.put("CPASSREPARTIDOR", jsonObject.getString("CPASSREPARTIDOR"));


                    valRepartos.put("NNUMREPARTO", jsonObject.getInt("NNUMREPARTO"));
                    valRepartos.put("CCODREPARTIDOR", jsonObject.getString("CCODREPARTIDOR"));
                    valRepartos.put("DFECREPARTO", jsonObject.getString("DFECREPARTO"));
                    valRepartos.put("CLOCALIDAD", jsonObject.getString("CLOCALIDAD"));
                    valRepartos.put("CDIRECCION", jsonObject.getString("CDIRECCION"));
                    valRepartos.put("BENTREGADO", jsonObject.getString("BENTREGADO"));
                    valRepartos.put("BACTUALIZADO", jsonObject.getString("BACTUALIZADO"));
                    valRepartos.put("NTOTAL", jsonObject.getInt("NTOTAL"));

                    valLocs.put("CLOCALIDAD", jsonObject.getString("CLOCALIDAD"));
                    valLocs.put("CPROVINCIA", jsonObject.getString("CPROVINCIA"));

                    valRepartosDet.put("NNUMREPARTO", jsonObject.getInt("NNUMREPARTO"));
                    valRepartosDet.put("NNUMLINEA", jsonObject.getInt("NNUMLINEA"));
                    valRepartosDet.put("CCODPRODUCTO", jsonObject.getString("CCODPRODUCTO"));
                    valRepartosDet.put("CDESPRODUCTO", jsonObject.getString("CDESPRODUCTO"));
                    valRepartosDet.put("NCANTIDAD", jsonObject.getInt("NCANTIDAD"));
                    valRepartosDet.put("NPRECIO", jsonObject.getInt("NPRECIO"));
                    valRepartosDet.put("NSUBTOTAL", jsonObject.getInt("NSUBTOTAL"));
                    valRepartosDet.put("COBSERVACIONES", jsonObject.getString("COBSERVACIONES"));


                    //solo la primera vez que quiera insertar el repartidor
                    if (primero) {
                        sdb.insert("repartidores", null, valRepartidores);
                        primero = false;
                    }

                    // Muestra un error a la hora de introducir una localidad que ya esta introducida, pero no afecta a la aplicacion
                    Cursor res = sdb.rawQuery("select clocalidad from localidades where clocalidad = '"+ jsonObject.getString("CLOCALIDAD")+"'",null);
                    res.moveToNext();
                    if (res.getCount()==0) {
                        sdb.insert("localidades", null, valLocs);
                    }
                    res.close();

                    res = sdb.rawQuery("select nnumreparto from repartos where nnumreparto = "+ jsonObject.getInt("NNUMREPARTO"),null);
                    res.moveToNext();
                    if (res.getCount()==0) {
                        sdb.insert("repartos", null, valRepartos);
                    }
                    res.close();
                    sdb.insert("repartosdetalle", null, valRepartosDet);


                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


}
