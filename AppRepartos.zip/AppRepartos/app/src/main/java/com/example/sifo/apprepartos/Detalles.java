package com.example.sifo.apprepartos;

import android.app.Activity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Sifo on 28/02/2016.
 */
public class Detalles extends Activity {
    Spinner linea;
    ArrayList<Integer> arraySpinner = new ArrayList<>();
    TextView numRep,codProd,descrip,cantidad,precio,subtotal,coments;
    SQLiteDatabase sdb;
    int codRep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detalles);

        linea = (Spinner)findViewById(R.id.lineaRep);
        numRep = (TextView)findViewById(R.id.nReparto);
        codProd = (TextView)findViewById(R.id.codProd);
        descrip = (TextView)findViewById(R.id.descrip);
        cantidad = (TextView)findViewById(R.id.cantidad);
        precio = (TextView)findViewById(R.id.precio);
        subtotal = (TextView)findViewById(R.id.subTotal);
        coments = (TextView)findViewById(R.id.coments);

        //cojemos el codigo de reparto de la actividad anterior
        Bundle datos = getIntent().getExtras();
        codRep = datos.getInt("codReparto");
        Log.e("CodigoReparto:",codRep+"");

        //hacemos la consulta en la bd local
        sdb = MainActivity.getBD().getReadableDatabase();
        Cursor res = sdb.rawQuery("SELECT nnumlinea FROM repartosdetalle WHERE nnumreparto = "+codRep,null);
        while(res.moveToNext()){
            arraySpinner.add(res.getInt(0));
        }
        res.close();
        //adaptador para rellenar el spinner
        ArrayAdapter<Integer> adapter = new ArrayAdapter<Integer>(this, android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        linea.setAdapter(adapter);

        numRep.setText(codRep + "");

        linea.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                int numlinea = arraySpinner.get(position);
                //numreparto,numlinea,codigoproducto,descripcion,cantidad,precio,subtotal,comentarios
                Cursor res = sdb.rawQuery("SELECT * FROM repartosdetalle WHERE nnumreparto ="+codRep+" and nnumlinea = "+numlinea,null);
                if (res.getCount()>0){
                    res.moveToNext();
                    Log.e("rescount",res.getCount()+"");
                    codProd.setText(res.getString(2));
                    descrip.setText(res.getString(3));
                    cantidad.setText(res.getInt(4)+"");
                    precio.setText(res.getInt(5)+"");
                    subtotal.setText(res.getInt(6)+"");
                    coments.setText(res.getString(7));
                }
                res.close();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });


    }
}
