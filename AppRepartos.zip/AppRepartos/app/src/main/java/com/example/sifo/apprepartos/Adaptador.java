package com.example.sifo.apprepartos;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Sifo on 17/02/2016.
 */
public class Adaptador extends BaseAdapter {
    private ArrayList<Reparto> lista;
    private final Activity actividad;


    public Adaptador(Activity a,ArrayList<Reparto> v){
        super();
        this.lista = v;
        this.actividad = a;
    }

    @Override
    public int getCount() {
        return lista.size();
    }

    @Override
    public Object getItem(int position) {
        return lista.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater ly = actividad.getLayoutInflater();
        View view = ly.inflate(R.layout.reparto, null, true);

        TextView localidad = (TextView) view.findViewById(R.id.localidad);//se crea un textview que enlace con el del layout de contacto
        localidad.setText(lista.get(position).getLocalidad());//se pone el texto que tenga el Elemento correspondiente a la posicion del listview

        TextView direccion = (TextView) view.findViewById(R.id.direccion);
        direccion.setText(lista.get(position).getDireccion());

        TextView total = (TextView) view.findViewById(R.id.total);
        total.setText(lista.get(position).getNum()+"");

        ImageView img = (ImageView) view.findViewById(R.id.imageView);
        img.setImageDrawable(lista.get(position).getDrawable());

        return view;
    }
}
