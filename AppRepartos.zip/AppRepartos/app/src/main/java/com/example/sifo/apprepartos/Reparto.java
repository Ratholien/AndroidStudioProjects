package com.example.sifo.apprepartos;

import android.graphics.drawable.Drawable;

import java.io.Serializable;

/**
 * Created by Sifo on 17/02/2016.
 */
public class Reparto implements Serializable {
    String localidad, direccion;
    int num;
    Drawable img;


        public Reparto(String localidad, String direccion, int num,Drawable d) {
            this.localidad = localidad;
            this.direccion = direccion;
            this.num = num;
            this.img = d;

    }
    public void setDrawable(Drawable d){
        this.img = d;
    }
    public Drawable getDrawable(){
        return this.img;
    }
    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
