package com.example.sifo.apprepartos;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Sifo on 15/02/2016.
 */
public class BDrepartos extends SQLiteOpenHelper {

    private static final String NOMBREBD = "BDrepartos.db";
    public static final int VERSIONBD = 1;

    private String trepartidores="CREATE TABLE repartidores (" +
            "CCODREPARTIDOR VARCHAR(13) PRIMARY KEY," +
            "CPASSREPARTIDOR VARCHAR(8) NOT NULL," +
            "CNOMREPARTIDOR VARCHAR(20) NOT NULL," +
            "DFECULTACT DATE NOT NULL" +
            ");";

    private String tlocalidades = "CREATE TABLE localidades (" +
            "CLOCALIDAD VARCHAR(30) PRIMARY KEY," +
            "CPROVINCIA VARCHAR(100) NOT NULL" +
            ");";

    private String trepartos="CREATE TABLE repartos (" +
            "NNUMREPARTO INTEGER PRIMARY KEY," +
            "CCODREPARTIDOR VARCHAR(13) NOT NULL," +
            "DFECREPARTO DATE NOT NULL," +
            "CLOCALIDAD VARCHAR(30) NOT NULL," +
            "CDIRECCION VARCHAR(100) NOT NULL," +
            "BENTREGADO VARCHAR(1) NOT NULL," +
            "BACTUALIZADO VARCHAR(1) NOT NULL," +
            "NTOTAL INTEGER," +
            "FOREIGN KEY (CCODREPARTIDOR) REFERENCES repartidores(CCODREPARTIDOR)," +
            "FOREIGN KEY (CLOCALIDAD) REFERENCES localidades(CLOCALIDAD)" +
            ");";

    private String trepartosdetalle="CREATE TABLE repartosdetalle (" +
            "NNUMREPARTO INTEGER ," +
            "NNUMLINEA INTEGER," +
            "CCODPRODUCTO VARCHAR(13) NOT NULL," +
            "CDESPRODUCTO VARCHAR(100) NOT NULL," +
            "NCANTIDAD INTEGER NOT NULL," +
            "NPRECIO INTEGER NOT NULL," +
            "NSUBTOTAL INTEGER NOT NULL," +
            "COBSERVACIONES VARCHAR(100) NOT NULL," +
            "FOREIGN KEY (NNUMREPARTO) REFERENCES repartos(NNUMREPARTO)," +
            "PRIMARY KEY (NNUMREPARTO,NNUMLINEA) );";

    public BDrepartos(Context context) {
        super(context, NOMBREBD, null, VERSIONBD);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(trepartidores);
        db.execSQL(tlocalidades);
        db.execSQL(trepartos);
        db.execSQL(trepartosdetalle);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS trepartosdetalle");
        db.execSQL("DROP TABLE IF EXISTS trepartos");
        db.execSQL("DROP TABLE IF EXISTS trepartidores");
        db.execSQL("DROP TABLE IF EXISTS tlocalidades");

        onCreate(db);
    }
}
