package com.example.sifo.apprepartos;

import android.os.Bundle;
import android.preference.PreferenceActivity;

/**
 * Created by Sifo on 18/02/2016.
 */
public class Preferencias extends PreferenceActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferencias);
    }
}
